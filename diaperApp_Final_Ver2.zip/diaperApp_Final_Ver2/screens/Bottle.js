import React, { Component } from 'react';
import { TextInput, StyleSheet, Text, View, TouchableOpacity, Alert, Button } from 'react-native';
import Modal from "react-native-modal";
// import Time from '../components/Time';
import firebase from '../firebase';
import DatePicker from 'react-native-datepicker';
import RNPickerSelect from 'react-native-picker-select';


var Dimensions = require('Dimensions');
var {width} = Dimensions.get('window');

export default class Bottle extends Component {

  activityDatabase = firebase.database().ref('activities'); 
  
  constructor(props) {
    super(props);
    this.state = {
      activities:{},
      amount: null,
      unit: '',
      date: new Date(),
      startTime: null,
    }
  }
  componentWillUnmount() {
    clearInterval(this.state.timer);
  }

  onButtonClear = () => {
    this.setState({
      amount: '',
      unit: '',
    });
  
  }

  create(){

    console.log(this.state.minutes_Counter);
    this.activityDatabase.push({category:"Bottle Feeding", feedingTime: 'N/A', startTime: this.state.startTime, amount: this.state.amount, unit: this.state.unit, userId: firebase.auth().currentUser.uid, date:　firebase.database.ServerValue.TIMESTAMP });

  }


  render() {
    return (
      <View style={styles.MainContainer}>
        <Text>Start Time</Text>
        <DatePicker
          style={{width: 200}}
          date={this.state.startTime}
          mode="time"
          format="HH:mm"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          minuteInterval={10}
          onDateChange={(date) => {this.setState({startTime: date})}}
        />
        <View>
        
          
          <View>
              <TextInput
                style={styles.input}
                placeholder="Input the amount"
                autoCapitalize="none"
                onChangeText={amount => this.setState({ amount })}
                value={this.state.amount}
            
              />
          </View>
            
          <RNPickerSelect
              selectedValue={this.state.unit}
              style={{height: 100, width: '100%', color: 'black'}}
              onValueChange={(itemValue) =>
                this.setState({unit: itemValue})
              }
              items={[
                  { label: 'ml', value: 'ml'},
                  { label: 'oz', value: 'oz' },
              ]}
          />
               
          
        </View>

        <TouchableOpacity
          onPress={this.onButtonClear}
          activeOpacity={0.6}
          style={styles.button}
        >
          <Text style={styles.buttonText}> CLEAR </Text>
        </TouchableOpacity>  

        <TouchableOpacity 
          onPress={() => this.create()}
          style={styles.button}
        >

          <Text style={{ color: "#FFF", fontWeight: "500" }}>Save</Text>
        </TouchableOpacity>
      </View>
        
    );
  }
}
const styles = StyleSheet.create({
  MainContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  button: {
    width: '80%',
    paddingTop:8,
    paddingBottom:8,
    borderRadius:7,
    marginTop: 10,
    backgroundColor: '#E9446A',
  },
  buttonText:{
      color:'#fff',
      textAlign:'center',
      fontSize: 20
  },
  input:{
    borderColor: '#B0BEC5',
    borderWidth: 1,
    width: '100%',
  }
 
});