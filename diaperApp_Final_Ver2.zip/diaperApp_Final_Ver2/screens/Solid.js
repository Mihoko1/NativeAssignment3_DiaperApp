import React from 'react';
import { Button, Text, View, Modal, Alert,Image } from 'react-native';
import styles from '../styles.js';

export default class Solid extends React.Component {
  state = {
    modalPaymentVisible: false,
    modalPrintVisible: false,
  };

  setModalPaymentVisible(visible) {
    this.setState({modalPaymentVisible: visible});
  }
  setModalPrintVisible(visible) {
    this.setState({modalPrintVisible: visible});
  }

  render() {
    return (
      <View style={styles.container}>
        <Text>This app is proudly sponsored by Cherub Baby Foods.</Text>
        <Text>Get 25% off your next order.</Text>
        <Image 
            source={{uri: 'https://media.giphy.com/media/igPJapPeOSLsjoMvMd/giphy.gif'}} 
            style={{width: 400, height: 400}}/>
      </View>
    );
  }
}